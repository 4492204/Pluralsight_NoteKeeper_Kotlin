package com.example.nootkeeper_kotlin

const val NOTE_POSITION = "NOTE_POSITION"
const val POSITION_NOTE_SET = -1